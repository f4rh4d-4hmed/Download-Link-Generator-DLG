import json
import requests
import re
import urllib.parse
from bs4 import BeautifulSoup
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler

URL_FILE_S1 = 's1.lock'
URL_FILE_S2 = 's2.lock'
URL_FILE_S3 = 's3.lock'
URL_FILE_S4 = 's4.lock'
URL_FILE_S5 = 's5.json'
URL_FILE_GAMES = 'games.json'  # New URL file for games
RESULTS_PER_PAGE = 10

def get_magnet_link(directory_url, remove_trackers=True):
    try:
        response = requests.get(f"https://kat.am{directory_url}")
        if response.status_code == 200:
            magnet_lines = re.findall(r'magnet:\?xt=urn:btih:[^\n]*announce\b', response.text)
            if magnet_lines:
                magnet_link = magnet_lines[0]
                if remove_trackers:
                    info_hash = re.search(r'urn:btih:([^&/]+)', magnet_link).group(1)
                    display_name = urllib.parse.unquote(re.search(r'dn=([^&/]+)', magnet_link).group(1))
                    magnet_link = f"magnet:?xt=urn:btih:{info_hash}&dn={display_name}"
                return magnet_link
    except Exception as e:
        print(f"Error getting magnet link: {e}")
    return None


async def start(update: Update, context) -> None:
    await update.message.reply_text('Hello! Welcome to this DLG bot. Use /help to see available commands.')

async def about(update: Update, context) -> None:
    await update.message.reply_text('This is a simple Telegram bot to search and download files. For more info: @f4rhad_ahmed')

async def help_command(update: Update, context) -> None:
    await update.message.reply_text('Commands:\n/start - Restart the bot{Not working yet}\n/about - Info about this bot\n/s1 <keyword> - Search in server #1. For example: /s1 Naruto\n/s2 <keyword> - Search in server #2 For example: "/s2 Assassins Creed"\n/s3 <keyword> - Search in server #3. For example: "/s3 K.G.F"\n/s4 <keyword> - Search in server #4. For example: "/s4 Money Heist"\n/s5 <keyword> - Search in server #5. For example: "/s5 Avatar"\n/games <keyword> - Search for games on FitGirl Repacks\n/any <keyword> - Search for torrents on KAT and send available magnet links\n/help - If needed, contact me via @f4rhad_ahmed')

async def s1(update: Update, context) -> None:
    query = update.message.text.split(maxsplit=1)
    if len(query) < 2:
        await update.message.reply_text('Make sure this http://172.16.50.4/ working on your network. Usage: /s1 <keyword>. Example: "/s1 Naruto."')
        return

    keyword = query[1].strip().lower()
    if keyword:
        matching_urls = search_urls(keyword, URL_FILE_S1)
        if matching_urls:
            await show_results(update, matching_urls)
            print("Searched For:{" + keyword + "}. In /s1")
        else:
            await update.message.reply_text('No matching URLs found in server 1. Try other command. If not found anywhere try /any')
    else:
        await update.message.reply_text('Please enter a keyword to search.')

async def s2(update: Update, context) -> None:
    query = update.message.text.split(maxsplit=1)
    if len(query) < 2:
        await update.message.reply_text('Make sure this http://vdomela.com/ working on your network. Usage: /s2 <keyword>. Example: "/s2 Iron Man 3"')
        return

    keyword = query[1].strip().lower()
    if keyword:
        matching_urls = search_urls(keyword, URL_FILE_S2)
        if matching_urls:
            await show_results(update, matching_urls)
            print("Searched For:{" + keyword + "}. In /s2")
        else:
            await update.message.reply_text('No matching URLs found in server 2. http://vdomela.com/ Is limited and have less files. Try other command. If not found anywhere try /any')
    else:
        await update.message.reply_text('Please enter a keyword for search.')

async def s3(update: Update, context) -> None:
    query = update.message.text.split(maxsplit=1)
    if len(query) < 2:
        await update.message.reply_text('Make sure this http://iplex.live/ working on your network. Usage: /s3 <keyword>. Example: "/s3 Naruto"')
        return

    keyword = query[1].strip().lower()
    if keyword:
        matching_urls = search_urls(keyword, URL_FILE_S3)
        if matching_urls:
            await show_results(update, matching_urls)
            print("Searched For:{" + keyword + "}. In /s3")
        else:
            await update.message.reply_text('No matching URLs found in server 3. Try other command. If not found anywhere try /any')
    else:
        await update.message.reply_text('Please enter a keyword for search.')

async def s4(update: Update, context) -> None:
    query = update.message.text.split(maxsplit=1)
    if len(query) < 2:
        await update.message.reply_text('Make sure this http://beeflix.biz/ working on your network. Usage: /s4 <Movie Name>. Example: "/s4 Kanchana"')
        return

    keyword = query[1].strip().lower()
    if keyword:
        matching_urls = search_urls(keyword, URL_FILE_S4)
        if matching_urls:
            await show_results(update, matching_urls)
        else:
            await update.message.reply_text('No matching URLs found in server #4. Try other command. If not found anywhere try /any')
            print("Searched For:{" + keyword + "}In /s4")
    else:
        await update.message.reply_text('Please enter a keyword to start searching.')

def search_urls(keyword, url_file):
    try:
        with open(url_file, 'r') as file:
            matching_urls = [line.strip() for line in file if all(
                word.lower() in line.lower() for word in keyword.split())]
        return matching_urls
    except FileNotFoundError:
        return []

async def show_results(update, matching_urls):
    message_text = "Matching URLs:\n"
    for url in matching_urls[:RESULTS_PER_PAGE]:
        file_name = url.split('/')[-1]
        formatted_name = re.sub(r'\.|%28|%29|720p|WEB-HD|x264|%20|%5|-|mkv|mp4|zip|_|rar|iso|FLAC d|1920x1080|1080p|720p|\+|480p|360p|1280x720|720x480|480x360|x265|WEB|HD|UHD|hd|uhd', ' ', file_name)

        keyboard = [
            [InlineKeyboardButton("Download", url=url)]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)

        message_text += f"Name: {formatted_name}\n"
        await update.message.reply_text(message_text, reply_markup=reply_markup)
        message_text = ""

async def s5(update: Update, context) -> None:
    query = update.message.text.split(maxsplit=1)
    if len(query) < 2:
        await update.message.reply_text('Make sure this http://146.196.48.9/ working on your network. Usage: /s5 <Movie Name>. Example: "/s5 Kanchana"')
        return

    keyword = query[1].strip().lower()
    if keyword:
        matching_files = search_files(keyword, URL_FILE_S5)
        if matching_files:
            await show_file_details(update, matching_files)
            print("Searched For:{" + keyword + "}. In /s5")
        else:
            await update.message.reply_text('No matching files found in server #5.')
    else:
        await update.message.reply_text('Please enter a keyword for search.')

def search_files(keyword, url_file):
    try:
        with open(url_file, 'r') as file:
            data = json.load(file)
            matching_files = [item for item in data if keyword in item['name'].lower()]
        return matching_files
    except FileNotFoundError:
        return []

async def show_file_details(update, matching_files):
    for file_details in matching_files:
        keyboard = [
            [InlineKeyboardButton("Download", url=file_details['url'])]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)

        await update.message.reply_text(f"Name: {file_details['name']}", reply_markup=reply_markup)


async def any_search(update: Update, context) -> None:
    query = update.message.text.split(maxsplit=1)
    if len(query) < 2:
        await update.message.reply_text('Usage: /any <keyword>. Example: /any Naruto')
        return

    search_input = query[1].strip()
    base_url = f"https://kat.am/usearch/{search_input}"
    try:
        response = requests.get(base_url)
        if response.status_code == 200:
            await update.message.reply_text(f"Searching for '{search_input}' online...")
            print("Searched For:{" + search_input + "}. In /any.")
            soup = BeautifulSoup(response.text, 'html.parser')
            links = soup.find_all('a', class_='cellMainLink', href=True)
            for link in links:
                directory_link = link['href']
                directory_name = link.text.strip()
                magnet_link = get_magnet_link(directory_link)
                if magnet_link:
                    await update.message.reply_text(f"Name: `{directory_name}`\nLink:\n```\n{magnet_link}\n```", parse_mode='MarkdownV2')
        else:
            await update.message.reply_text(f"Failed to search for '{search_input}' online.")
    except Exception as e:
        await update.message.reply_text(f"An error occurred: {e}")

async def games_search(update: Update, context) -> None:
    query = update.message.text.split(maxsplit=1)
    if len(query) < 2:
        await update.message.reply_text('Usage: /games <keyword>. Example: /games GTA')
        return

    search_input = query[1].strip()
    base_url = f"https://fitgirl-repacks.site/search/{urllib.parse.quote(search_input)}"
    try:
        response = requests.get(base_url)
        if response.status_code == 200:
            await update.message.reply_text(f"Searching for '{search_input}' online...")
            print(f"Searched For:{{{search_input}}}. In /games.")
            soup = BeautifulSoup(response.text, 'html.parser')
            entries = soup.find_all('header', class_='entry-header')
            for entry in entries:
                entry_title = entry.find('h1', class_='entry-title')
                name = entry_title.text.strip()
                directory_link = f"{entry_title.find('a', href=True)['href']}"
                directory_response = requests.get(directory_link)
                if directory_response.status_code == 200:
                    directory_soup = BeautifulSoup(directory_response.text, 'html.parser')
                    magnet_link = directory_soup.find('a', href=re.compile(r'magnet:\?xt=urn:btih:[^\n]*announce\b'))
                    if magnet_link:
                        magnet_url = magnet_link['href']
                        # Reformating magnet link
                        info_hash_games = re.search(r'urn:btih:([^&/]+)', magnet_url)
                        display_name_games = re.search(r'dn=([^&/]+)', magnet_url)
                        if info_hash_games and display_name_games:
                            info_hash_games = info_hash_games.group(1)
                            display_name_games = urllib.parse.unquote(display_name_games.group(1))
                            reformatted_magnet_link = f"magnet:?xt=urn:btih:{info_hash_games}&dn={display_name_games}"
                            await update.message.reply_text(f"Name: `{name}`\nLink:\n```\n{reformatted_magnet_link}\n```", parse_mode='MarkdownV2')
                        else:
                            await update.message.reply_text("Error: Unable to parse magnet link.")
                    else:
                        print("No magnet link found.")
                else:
                    print("Failed to fetch directory page.")
        else:
            await update.message.reply_text(f"Failed to search for '{search_input}' online")
    except Exception as e:
        await update.message.reply_text(f"An error occurred: {e}")


def main():
    application = Application.builder().token('7070288763:AAHSIhaVAFu7KXgtPpI6RT_aJ5pfbEo6k7s').build()

    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("about", about))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("s1", s1))
    application.add_handler(CommandHandler("s2", s2))
    application.add_handler(CommandHandler("s3", s3))
    application.add_handler(CommandHandler("s4", s4))
    application.add_handler(CommandHandler("s5", s5))
    application.add_handler(CommandHandler("games", games_search))
    application.add_handler(CommandHandler("any", any_search))

    application.run_polling()

if __name__ == '__main__':
    main()